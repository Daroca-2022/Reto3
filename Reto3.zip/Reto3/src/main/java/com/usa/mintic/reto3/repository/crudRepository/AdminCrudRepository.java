package com.usa.mintic.reto3.repository.crudRepository;


import com.usa.mintic.reto3.model.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminCrudRepository extends CrudRepository<Admin,Integer> {
}
