package com.usa.mintic.reto3.repository.crudRepository;


import com.usa.mintic.reto3.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client,Integer> {
}
