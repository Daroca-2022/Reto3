package com.usa.mintic.reto3.repository.crudRepository;


import com.usa.mintic.reto3.model.Machine;
import org.springframework.data.repository.CrudRepository;

public interface MachineCrudRepository extends CrudRepository<Machine,Integer> {
}
