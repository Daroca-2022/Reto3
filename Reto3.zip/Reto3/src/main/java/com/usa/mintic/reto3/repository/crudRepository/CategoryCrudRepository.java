package com.usa.mintic.reto3.repository.crudRepository;


import com.usa.mintic.reto3.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category,Integer> {
}
